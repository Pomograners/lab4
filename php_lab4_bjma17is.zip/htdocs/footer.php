<p>Footer information</p>
<?php echo "Entred: " . date("l") . " " . date("d") . " of " . date("F"); ?> <br>
<a class="link" href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
<a class="link" href="https://www.facebook.com/"><i class="fab fa-facebook"></i></a>