<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css.css">
	<link href="https://fonts.googleapis.com/css?family=Hind" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Teko" rel="stylesheet">


</head>
<header>
	<?php include 'header.php'; ?>
	<img src="header-img.png">
</header>
<body>
	<content>
		<form>
			<p>Currently not working</p>
			<input type="text" name="name" placeholder="Name"> <br>
			<input type="email" name="email" placeholder="E-mail"> <br>
			<textarea placeholder="Message"></textarea> <br>
			<input disabled="true" type="submit" value="Send">
		</form>
	</content>
</body>
<footer>
	<?php include 'footer.php'; ?>
</footer>
</html>

